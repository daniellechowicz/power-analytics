__version_info__ = (1, 2, 0)
__version__ = '.'.join('%d' % d for d in __version_info__)
